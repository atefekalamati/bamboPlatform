import { ROUTES } from "../constants/routes.js";
import { AppShell } from "../layouts/AppShell.js";
import { DashboardPage } from "../pages/DashboardPage.js";
import { PilotDetailsPage } from "../pages/PilotDetailsPage.js";
import { PilotsPage } from "../pages/PilotsPage.js";
import { RolesPage } from "../pages/RolesPage.js";
import { StageOnePage } from "../pages/StageOnePage.js";
import { StageTwoPage } from "../pages/StageTwoPage.js";
import { StageThreePage } from "../pages/StageThreePage.js";
import { StageFourPage } from "../pages/StageFourPage.js";
import { StageFivePage } from "../pages/StageFivePage.js";
import { StageSixPage } from "../pages/StageSixPage.js";
import { StageSevenPage } from "../pages/StageSevenPage.js";
import { StageEightPage } from "../pages/StageEightPage.js";
import { StageNinePage } from "../pages/StageNinePage.js";
import { StageTenPage } from "../pages/StageTenPage.js";
import { StageElevenPage } from "../pages/StageElevenPage.js";
import { StageTwelvePage } from "../pages/StageTwelvePage.js";
import { StageThirteenPage } from "../pages/StageThirteenPage.js";
import { StageFourteenPage } from "../pages/StageFourteenPage.js";
import { StageFifteenPage } from "../pages/StageFifteenPage.js";
import { StageSixteenPage } from "../pages/StageSixteenPage.js";
import { StageSeventeenPage } from "../pages/StageSeventeenPage.js";
import { StageEighteenPage } from "../pages/StageEighteenPage.js";
import { StageNineteenPage } from "../pages/StageNineteenPage.js";
import { UsersPage } from "../pages/UsersPage.js";
import { NotificationsPage } from "../pages/NotificationsPage.js";
import { NotificationPreferencesPage } from "../pages/NotificationPreferencesPage.js";
import { IncidentsPage } from "../pages/IncidentsPage.js";
import { IncidentCreatePage } from "../pages/IncidentCreatePage.js";
import { IncidentDetailPage } from "../pages/IncidentDetailPage.js";
import {
  ReportsOverviewPage,
  PilotProgressReportPage,
  ActionsReportPage,
  KpiReportPage,
  IncidentReportPage,
  PilotOnePageReportPage,
} from "../pages/ReportsPage.js";
import {
  canLeaveCurrentPage,
  clearNavigationGuard,
  hasNavigationGuard,
} from "./navigationGuard.js";
import { sessionStore } from "./sessionStore.js";
import { canAccessRoute, requiredPermissionForRoute } from "./routePermissions.js";

const accessDeniedPage = (route) => {
  const page = document.createElement("main");
  const heading = document.createElement("h1");
  const message = document.createElement("p");
  const back = document.createElement("a");
  page.className = "page error-state";
  heading.textContent = "دسترسی به این صفحه امکان‌پذیر نیست";
  message.textContent = `مجوز لازم برای این مسیر (${requiredPermissionForRoute(route) ?? "نامشخص"}) در حساب شما وجود ندارد.`;
  back.className = "button button--primary";
  back.href = ROUTES.dashboard;
  back.textContent = "بازگشت به نمای کلی";
  page.append(heading, message, back);
  return page;
};

const ROUTE_FACTORIES = Object.freeze({
  [ROUTES.dashboard]: DashboardPage,
  [ROUTES.pilots]: PilotsPage,
  [ROUTES.users]: UsersPage,
  [ROUTES.roles]: RolesPage,
  [ROUTES.notifications]: NotificationsPage,
  [ROUTES.notificationSettings]: NotificationPreferencesPage,
  [ROUTES.incidents]: IncidentsPage,
  [ROUTES.reports]: ReportsOverviewPage,
  [ROUTES.reportPilots]: PilotProgressReportPage,
  [ROUTES.reportActions]: ActionsReportPage,
  [ROUTES.reportKpis]: KpiReportPage,
  [ROUTES.reportIncidents]: IncidentReportPage,
});

const getCurrentRoute = () => window.location.hash || ROUTES.dashboard;

const resolveRoute = (currentRoute) => {
  const permissions = sessionStore.getCurrentUser()?.permissions ?? [];
  if (!canAccessRoute(currentRoute, permissions)) {
    return { page: accessDeniedPage(currentRoute), navigationRoute: "" };
  }
  const routePath = currentRoute.split("?")[0];
  const exactPageFactory = ROUTE_FACTORIES[routePath];

  if (exactPageFactory) {
    return {
      page: exactPageFactory(),
      navigationRoute: routePath.startsWith("#/reports") ? ROUTES.reports : routePath,
    };
  }

  const reportPilotMatch = routePath.match(/^#\/reports\/pilots\/([^/?#]+)$/);
  if (reportPilotMatch) {
    return { page: PilotOnePageReportPage({ pilotId: reportPilotMatch[1] }), navigationRoute: ROUTES.reports };
  }

  const pilotDetailsMatch = routePath.match(/^#\/pilots\/([^/]+)$/);
  const incidentCreateMatch = currentRoute.match(/^#\/pilots\/([^/]+)\/incidents\/new$/);
  const incidentDetailMatch = currentRoute.match(/^#\/incidents\/([^/?#]+)$/);
  const notificationDetailsMatch = currentRoute.match(/^#\/notifications\/([^/?#]+)$/);
  const stageOneMatch = currentRoute.match(
    /^#\/pilots\/([^/]+)\/stages\/1$/,
  );
  const stageTwoMatch = currentRoute.match(
    /^#\/pilots\/([^/]+)\/stages\/2$/,
  );
  const stageThreeMatch = currentRoute.match(
    /^#\/pilots\/([^/]+)\/stages\/3$/,
  );
  const stageFourMatch = currentRoute.match(
    /^#\/pilots\/([^/]+)\/stages\/4$/,
  );
  const stageFiveMatch = currentRoute.match(
    /^#\/pilots\/([^/]+)\/stages\/5$/,
  );
  const stageSixMatch = currentRoute.match(
    /^#\/pilots\/([^/]+)\/stages\/6$/,
  );
  const stageSevenMatch = currentRoute.match(
    /^#\/pilots\/([^/]+)\/stages\/7$/,
  );
  const stageEightMatch = currentRoute.match(
    /^#\/pilots\/([^/]+)\/stages\/8$/,
  );
  const stageNineMatch = currentRoute.match(
    /^#\/pilots\/([^/]+)\/stages\/9$/,
  );
  const stageTenMatch = currentRoute.match(
    /^#\/pilots\/([^/]+)\/stages\/10$/,
  );
  const stageElevenMatch = currentRoute.match(
    /^#\/pilots\/([^/]+)\/stages\/11$/,
  );
  const stageTwelveMatch = currentRoute.match(
    /^#\/pilots\/([^/]+)\/stages\/12$/,
  );
  const stageThirteenMatch = currentRoute.match(
    /^#\/pilots\/([^/]+)\/stages\/13$/,
  );
  const stageFourteenMatch = currentRoute.match(
    /^#\/pilots\/([^/]+)\/stages\/14$/,
  );
  const stageFifteenMatch = currentRoute.match(
    /^#\/pilots\/([^/]+)\/stages\/15$/,
  );
  const stageSixteenMatch = currentRoute.match(
    /^#\/pilots\/([^/]+)\/stages\/16$/,
  );
  const stageSeventeenMatch = currentRoute.match(
    /^#\/pilots\/([^/]+)\/stages\/17$/,
  );
  const stageEighteenMatch = currentRoute.match(
    /^#\/pilots\/([^/]+)\/stages\/18$/,
  );
  const stageNineteenMatch = currentRoute.match(
    /^#\/pilots\/([^/]+)\/stages\/19$/,
  );

  if (incidentCreateMatch) {
    return {
      page: IncidentCreatePage({ pilotId: incidentCreateMatch[1] }),
      navigationRoute: ROUTES.incidents,
    };
  }

  if (incidentDetailMatch) {
    return {
      page: IncidentDetailPage({ incidentId: incidentDetailMatch[1] }),
      navigationRoute: ROUTES.incidents,
    };
  }

  if (notificationDetailsMatch) {
    return {
      page: NotificationsPage({ notificationId: decodeURIComponent(notificationDetailsMatch[1]) }),
      navigationRoute: ROUTES.notifications,
    };
  }

  if (stageNineteenMatch) {
    return {
      page: StageNineteenPage({ pilotId: stageNineteenMatch[1] }),
      navigationRoute: ROUTES.pilots,
    };
  }

  if (stageEighteenMatch) {
    return {
      page: StageEighteenPage({ pilotId: stageEighteenMatch[1] }),
      navigationRoute: ROUTES.pilots,
    };
  }

  if (stageSeventeenMatch) {
    return {
      page: StageSeventeenPage({ pilotId: stageSeventeenMatch[1] }),
      navigationRoute: ROUTES.pilots,
    };
  }

  if (stageSixteenMatch) {
    return {
      page: StageSixteenPage({ pilotId: stageSixteenMatch[1] }),
      navigationRoute: ROUTES.pilots,
    };
  }

  if (stageFifteenMatch) {
    return {
      page: StageFifteenPage({ pilotId: stageFifteenMatch[1] }),
      navigationRoute: ROUTES.pilots,
    };
  }

  if (stageFourteenMatch) {
    return {
      page: StageFourteenPage({ pilotId: stageFourteenMatch[1] }),
      navigationRoute: ROUTES.pilots,
    };
  }

  if (stageThirteenMatch) {
    return {
      page: StageThirteenPage({ pilotId: stageThirteenMatch[1] }),
      navigationRoute: ROUTES.pilots,
    };
  }

  if (stageTwelveMatch) {
    return {
      page: StageTwelvePage({ pilotId: stageTwelveMatch[1] }),
      navigationRoute: ROUTES.pilots,
    };
  }

  if (stageElevenMatch) {
    return {
      page: StageElevenPage({ pilotId: stageElevenMatch[1] }),
      navigationRoute: ROUTES.pilots,
    };
  }

  if (stageTenMatch) {
    return {
      page: StageTenPage({ pilotId: stageTenMatch[1] }),
      navigationRoute: ROUTES.pilots,
    };
  }

  if (stageNineMatch) {
    return {
      page: StageNinePage({ pilotId: stageNineMatch[1] }),
      navigationRoute: ROUTES.pilots,
    };
  }

  if (stageEightMatch) {
    return {
      page: StageEightPage({ pilotId: stageEightMatch[1] }),
      navigationRoute: ROUTES.pilots,
    };
  }

  if (stageSevenMatch) {
    return {
      page: StageSevenPage({ pilotId: stageSevenMatch[1] }),
      navigationRoute: ROUTES.pilots,
    };
  }

  if (stageSixMatch) {
    return {
      page: StageSixPage({ pilotId: stageSixMatch[1] }),
      navigationRoute: ROUTES.pilots,
    };
  }

  if (stageFiveMatch) {
    return {
      page: StageFivePage({ pilotId: stageFiveMatch[1] }),
      navigationRoute: ROUTES.pilots,
    };
  }

  if (stageFourMatch) {
    return {
      page: StageFourPage({ pilotId: stageFourMatch[1] }),
      navigationRoute: ROUTES.pilots,
    };
  }

  if (stageThreeMatch) {
    return {
      page: StageThreePage({ pilotId: stageThreeMatch[1] }),
      navigationRoute: ROUTES.pilots,
    };
  }

  if (stageTwoMatch) {
    return {
      page: StageTwoPage({ pilotId: stageTwoMatch[1] }),
      navigationRoute: ROUTES.pilots,
    };
  }

  if (stageOneMatch) {
    return {
      page: StageOnePage({ pilotId: stageOneMatch[1] }),
      navigationRoute: ROUTES.pilots,
    };
  }

  if (pilotDetailsMatch) {
    return {
      page: PilotDetailsPage({ pilotId: pilotDetailsMatch[1] }),
      navigationRoute: ROUTES.pilots,
    };
  }

  return {
    page: DashboardPage(),
    navigationRoute: ROUTES.dashboard,
  };
};

const renderRoute = (appRoot) => {
  const currentRoute = getCurrentRoute();
  const resolvedRoute = resolveRoute(currentRoute);

  appRoot.replaceChildren(
    AppShell({
      content: resolvedRoute.page,
      currentRoute: resolvedRoute.navigationRoute,
    }),
  );
};

export const startRouter = (appRoot) => {
  let renderedRoute = getCurrentRoute();
  let isRestoringRoute = false;

  renderRoute(appRoot);
  window.addEventListener("hashchange", async () => {
    if (isRestoringRoute) {
      isRestoringRoute = false;
      return;
    }

    const nextRoute = getCurrentRoute();
    if (!(await canLeaveCurrentPage())) {
      isRestoringRoute = true;
      window.location.hash = renderedRoute;
      return;
    }

    clearNavigationGuard();
    renderedRoute = nextRoute;
    renderRoute(appRoot);
  });
  window.addEventListener("beforeunload", (event) => {
    if (!hasNavigationGuard()) return;

    event.preventDefault();
    event.returnValue = "";
  });
};
