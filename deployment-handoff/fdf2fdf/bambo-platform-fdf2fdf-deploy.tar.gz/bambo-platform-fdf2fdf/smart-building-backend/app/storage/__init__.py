"""Storage adapters."""
