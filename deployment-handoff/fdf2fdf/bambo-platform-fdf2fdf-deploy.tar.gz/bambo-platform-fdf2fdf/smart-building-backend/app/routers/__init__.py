"""FastAPI routers."""
